package org.fhi360.lamis.biometric.model;

import lombok.Data;

@Data
public class Device {
    private String id;
    private String name;
}
